#!/bin/bash
pkill -f MyDotNetApp.dll || true