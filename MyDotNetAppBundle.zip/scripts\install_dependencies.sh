#!/bin/bash
sudo yum update -y
sudo yum install -y dotnet-runtime-8.0